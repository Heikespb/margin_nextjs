import Mail from '../../src/components/emails/quotation-form-email.tsx';
export default Mail;