import Mail from '../../src/components/emails/contact-form-email.tsx';
export default Mail;