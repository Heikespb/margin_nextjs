module.exports = {
  quoteProps: 'consistent',
  singleQuote: true,
  trailingComma: 'all',
  printWidth: 80,
  useTabs: false,
  bracketSpacing: true,
};
